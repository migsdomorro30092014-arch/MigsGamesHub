const car = document.getElementById('car');
const obstacle = document.getElementById('obstacle');
const game = document.getElementById('game');
const scoreDisplay = document.getElementById('score');
let score = 0;
let carLeft = 175;
let obstacleLeft = Math.floor(Math.random() * 350);
let obstacleTop = -80;
let gameLoopInterval;

document.addEventListener('keydown', (event) => {
    if (event.key === 'ArrowLeft' && carLeft > 0) {
        carLeft -= 20;
    }
    if (event.key === 'ArrowRight' && carLeft < 350) {
        carLeft += 20;
    }
    car.style.left = carLeft + 'px';
});

game.addEventListener('touchstart', (event) => {
    event.preventDefault();

    const touchX = event.touches[0].clientX;
    
    const gameRect = game.getBoundingClientRect();
    
    const gameMidPoint = gameRect.left + gameRect.width / 2;

    if (touchX < gameMidPoint) {
        if (carLeft > 0) {
            carLeft -= 30;
        }
    } else {
        if (carLeft < 350) {
            carLeft += 30;
        }
    }
    car.style.left = carLeft + 'px';
});

function gameLoop() {
    obstacleTop += 5;
    if (obstacleTop > 600) {
        obstacleTop = -80;
        obstacleLeft = Math.floor(Math.random() * 350);
        score++;
        scoreDisplay.innerText = `Pontuação: ${score}`;
    }
    obstacle.style.top = obstacleTop + 'px';
    obstacle.style.left = obstacleLeft + 'px';

    if (
        carLeft < obstacleLeft + 50 &&
        carLeft + 50 > obstacleLeft &&
        520 < obstacleTop + 80 &&
        600 > obstacleTop
    ) {
        alert(`Fim de Jogo! Sua pontuação foi: ${score}`);
        clearInterval(gameLoopInterval);
        document.location.reload();
    }
}

gameLoopInterval = setInterval(gameLoop, 16);
