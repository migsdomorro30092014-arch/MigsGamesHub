const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const bird = {
    x: 50,
    y: canvas.height / 2,
    width: 20,
    height: 20,
    gravity: 0.6,
    lift: -15,
    velocity: 0,
    draw() {
        ctx.fillStyle = 'yellow';
        ctx.fillRect(this.x, this.y, this.width, this.height);
    },
    update() {
        this.velocity += this.gravity;
        this.y += this.velocity;

        if (this.y + this.height > canvas.height) {
            this.y = canvas.height - this.height;
            this.velocity = 0;
        }

        if (this.y < 0) {
            this.y = 0;
            this.velocity = 0;
        }
    },
    flap() {
        this.velocity += this.lift;
    }
};

const pipes = [];
let frameCount = 0;
let isGameActive = true;
let animationId; 

function drawPipes() {
    const gap = 150;
    
    for (let i = pipes.length - 1; i >= 0; i--) {
        const p = pipes[i];
        p.x -= 2;
        ctx.fillStyle = 'green';
        ctx.fillRect(p.x, 0, p.width, p.top);
        ctx.fillRect(p.x, p.top + gap, p.width, canvas.height - p.top - gap);

        if (p.x + p.width < 0) {
            pipes.splice(i, 1);
        }

        if (
            bird.x < p.x + p.width &&
            bird.x + bird.width > p.x &&
            (bird.y < p.top || bird.y + bird.height > p.top + gap)
        ) {
            
            if (isGameActive) {
                isGameActive = false; 
                cancelAnimationFrame(animationId);
                alert('Fim de Jogo!');
                document.location.reload();
            }
        }
    }
}

function gameLoop() {
    if (!isGameActive) {
        return;
    }

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    bird.draw();
    bird.update();
    drawPipes();

    if (frameCount % 100 === 0) {
        const minTop = 50;
        const gap = 150;
        const maxTop = canvas.height - 50 - gap;
        const top = Math.floor(Math.random() * (maxTop - minTop + 1)) + minTop;
        pipes.push({ x: canvas.width, top: top, width: 30 });
    }

    frameCount++;
    animationId = requestAnimationFrame(gameLoop);
}

document.addEventListener('keydown', (e) => {
    if (isGameActive && e.code === 'Space') {
        bird.flap();
    }
});

document.addEventListener('touchstart', (e) => {
    if (isGameActive) {
        e.preventDefault();
        bird.flap();
    }
});

gameLoop();
